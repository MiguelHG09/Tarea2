package Tarea2

// Este ejemplo muestra una cola de prioridad creada con la interfaz de almacenamiento dinámico.

import (
	"container/heap"
	"fmt"
)

// An Item is something we manage in a priority queue.
type Item struct {
	value int

	// El índice es necesario para la actualización y lo mantienen los métodos heap.Interface.
	index int
}

// PriorityQueue implementa heap.Interface y contiene elementos.
type PriorityQueue []*Item

func (pq PriorityQueue) Len() int { return len(pq) }

func (pq PriorityQueue) Less(i, j int) bool {
	// Queremos que Pop nos dé la prioridad más alta, no la más baja, por lo que usamos > aquí.
	return pq[i].priority > pq[j].priority
}

func (pq PriorityQueue) Swap(i, j int) {
	pq[i], pq[j] = pq[j], pq[i]
	pq[i].index = i
	pq[j].index = j
}

func (pq *PriorityQueue) Push(x interface{}) {
	n := len(*pq)
	item := x.(*Item)
	item.index = n
	*pq = append(*pq, item)
}

func (pq *PriorityQueue) Pop() interface{} {
	old := *pq
	n := len(old)
	item := old[n-1]
	item.index = -1 // for safety
	*pq = old[0 : n-1]
	return item
}

// update modifica la prioridad y el valor de un elemento en la cola.
func (pq *PriorityQueue) update(item *Item, value int, priority int) {
	item.value = value
	item.priority = priority
	heap.Fix(pq, item.index)
}

// Este ejemplo crea un PriorityQueue con algunos elementos, agrega y manipula un elemento, y luego elimina los elementos en orden de prioridad.
func main() {
	//algunos items y sus prioridades
	items := map[int]int{
		1: 10, 2: 20, 3: 5,
	}
	// Crea una cola de prioridad, coloca los elementos en ella y establece los invariantes de la cola de prioridad (heap).
	pq := make(PriorityQueue, len(items))
	i := 0
	pq.Push(&Item{value: 0, priority: 0})
	for value, priority := range items {
		pq[i] = &Item{
			value:    value,
			priority: priority,
			index:    i,
		}
		i++
	}
	heap.Init(&pq)

	// Saque los items u objetos; llegan en orden decreciente de prioridad gracias a lo anterior implementado

	fmt.Println(heap.Pop(&pq).(*Item))
	fmt.Println(heap.Pop(&pq).(*Item))
	fmt.Println(heap.Pop(&pq).(*Item))
	fmt.Println(heap.Pop(&pq).(*Item))
}
